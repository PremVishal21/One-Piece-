<?php
session_start();
if (isset($_SESSION["user"])) {
   header("Location: index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@600&display=swap" rel="stylesheet"> <!-- Google Font -->
    <style>
        body {
            font-family: 'Poppins', sans-serif; /* Updated font */
            margin: 0;
            padding: 0;
            background-image: url('pics/output-onlinepngtools (1).png'); /* Set background image */
            background-size: cover; /* Cover the entire background */
            background-position: center; /* Center the background image */
            overflow-x: hidden;
            overflow-y: hidden;
        }

        header {
            background: rgba(255, 255, 255, 0.8); /* Semi-transparent background for header */
            padding: 1.5em;
            text-align: center;
            border-bottom: 2px solid #fff;
            animation: fadeIn 1s; /* Fade-in animation */
            display: flex;
            justify-content: center; /* Center image horizontally */
            align-items: center; /* Center image vertically */
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        h1 {
            color: violet;
            text-align: center;
            animation: slideIn 1s; /* Slide-in animation */
        }

        @keyframes slideIn {
            from { transform: translateY(-20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        hr {
            color: aqua;
            border: 2px;
        }

        .container {
            width: 400px;
            margin: 50px auto;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.8); /* Slightly more transparent for better visibility */
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            text-align: left;
        }

        .form-group {
            margin: 10px 0;
        }

        .form-group input {
            width: 380px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            transition: border-color 0.3s, transform 0.3s;
        }

        .form-group input:focus {
            border-color: #4CAF50;
            transform: scale(1.02);
        }

        .form-btn input {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            width: 100%;
        }

        .form-btn input:hover {
            background-color: #45a049;
        }

        .signup-link {
            text-align: center;
            margin-top: 15px;
            transition: transform 0.3s;
        }

        .signup-link:hover {
            transform: scale(1.1);
            color: #4CAF50;
        }

        .alert {
            margin-top: 10px;
            padding: 10px;
            border-radius: 5px;
        }

        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
        }
        nav {
            margin: 20px 0;
        }
        nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center; /* Center the navigation */
        }
        nav li {
            margin: 0 15px; /* Space between boxes */
        }
        nav a {
            display: block; /* Make the link a block element */
            background-color: rgba(255, 255, 255, 0.8); /* Light background for boxes */
            padding: 12px 25px; /* Padding for the boxes */
            border-radius: 8px; /* Rounded corners */
            text-decoration: none;
            color: #333;
            transition: background-color 0.3s, transform 0.3s; /* Smooth transition */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Shadow for depth */
        }
        nav a:hover {
            background-color: #ddd; /* Darker background on hover */
            transform: translateY(-2px); /* Lift effect on hover */
        }
    </style>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Registration Form</title>
</head>
<body>
    <header>
        <!-- Replace the header text with an image -->
        <h1><img src="pics/one_piesece-removebg-preview.png" alt="One Piece Image" style="max-width: 300px; max-height: 150px; object-fit: contain;"></h1>

    </header>

    <div class="container">
        <?php
        if (isset($_POST["submit"])) {
           $fullName = $_POST["fullname"];
           $email = $_POST["email"];
           $password = $_POST["password"];
           $passwordRepeat = $_POST["repeat_password"];
           
           $passwordHash = password_hash($password, PASSWORD_DEFAULT);

           $errors = array();
           
           if (empty($fullName) OR empty($email) OR empty($password) OR empty($passwordRepeat)) {
            array_push($errors,"All fields are required");
           }
           if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
            array_push($errors, "Email is not valid");
           }
           if (strlen($password)<8) {
            array_push($errors,"Password must be at least 8 characters long");
           }
           if ($password!==$passwordRepeat) {
            array_push($errors,"Password does not match");
           }
           require_once "database.php";
           $sql = "SELECT * FROM users WHERE email = '$email'";
           $result = mysqli_query($conn, $sql);
           $rowCount = mysqli_num_rows($result);
           if ($rowCount>0) {
            array_push($errors,"Email already exists!");
           }
           if (count($errors)>0) {
            foreach ($errors as $error) {
                echo "<div class='alert alert-danger'>$error</div>";
            }
           }else{
            
            $sql = "INSERT INTO users (full_name, email, password) VALUES ( ?, ?, ? )";
            $stmt = mysqli_stmt_init($conn);
            $prepareStmt = mysqli_stmt_prepare($stmt,$sql);
            if ($prepareStmt) {
                mysqli_stmt_bind_param($stmt,"sss",$fullName, $email, $passwordHash);
                mysqli_stmt_execute($stmt);
                $_SESSION["student_name"] = $fullName; // Store the student's name in the session
                echo "<div class='alert alert-success'>You are registered successfully.</div>";
            }else{
                die("Something went wrong");
            }
           }
        }
        ?>
        <nav>
        </nav>
        <form action="registration.php" method="post">
            <h1>Registration Page</h1>
            <hr>
            <div class="form-group">
                <input type="text" class="form-control" name="fullname" placeholder="Full Name:" required>
            </div>
            <div class="form-group">
                <input type="email" class="form-control" name="email" placeholder="Email:" required>
            </div>
            <div class="form-group">
                <input type="password" class="form-control" name="password" placeholder="Password:" required>
            </div>
            <div class="form-group">
                <input type="password" class="form-control" name="repeat_password" placeholder="Repeat Password:" required>
            </div>
            <div class="form-btn">
                <input type="submit" class="btn btn-primary" value="Register" name="submit">
            </div>
        </form>

        <div class="signup-link">
            <p>Already Registered? <a href="login.php">Login Here</a></p>
        </div>
        
    </div>
</body>
</html>
