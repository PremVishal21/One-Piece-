<?php
session_start();
if (!isset($_SESSION["user"])) {
   header("Location:login.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <title>Course List</title>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
            header {
                background: rgba(255, 255, 255, 0.8); /* Semi-transparent background for header */
                color: #fff; /* White text for contrast */
                padding: 1.5em; /* Increased padding */
                text-align: center;
                border-bottom: 2px solid #fff; /* Bottom border for separation */
            }
            nav {
                margin: 20px 0;
            }
            nav ul {
                list-style: none;
                margin: 0;
                padding: 0;
                display: flex;
                justify-content: center; /* Center the navigation */
            }
            nav li {
                margin: 0 15px; /* Space between boxes */
            }
            nav a {
                display: block; /* Make the link a block element */
                background-color: rgba(255, 255, 255, 0.8); /* Light background for boxes */
                padding: 12px 25px; /* Padding for the boxes */
                border-radius: 8px; /* Rounded corners */
                text-decoration: none;
                color: #333;
                transition: background-color 0.3s, transform 0.3s; /* Smooth transition */
                box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Shadow for depth */
            }
            nav a:hover {
                background-color: #ddd; /* Darker background on hover */
                transform: translateY(-2px); /* Lift effect on hover */
            }
         body {
            background-image: url('pics/output-onlinepngtools (1).png'); 
            font-family: Arial, sans-serif;
                margin:auto;
                padding: 0;
                background-size: cover; /* Cover the entire background */
                background-position: center; /* Center the background image */
                overflow-x: hidden; /* Prevent horizontal scroll */
            }
            .course-list {
                padding: 20px;
                background-color: rgba(255, 255, 255, 0.9); /* Light background for contrast */
                margin: 20px;
                border-radius: 8px;
            }
            .course-item {
                margin: 15px 0;
                padding: 15px;
                border: 1px solid #ccc; /* Border for course items */
                border-radius: 8px;
                background-color: rgba(255, 255, 255, 0.8); /* Light background for course items */
                display: flex; /* Flexbox for layout */
                align-items: center; /* Center items vertically */
            }
            .course-item img {
                width: 100px; /* Set image width */
                height: auto; /* Maintain aspect ratio */
                margin-right: 15px; /* Space between image and text */
                border-radius: 5px; /* Rounded corners for images */
            }
            .enroll-button {
                background-color: #4CAF50; /* Green */
                border: none;
                color: white;
                padding: 10px 20px;
                text-align: center;
                text-decoration: none;
                display: inline-block;
                font-size: 16px;
                margin: 4px 2px;
                cursor: pointer;
                border-radius: 5px;
                transition: background-color 0.3s; /* Smooth transition */
            }
            .enroll-button:hover {
                background-color: #45a049; /* Darker green on hover */
            }
            .logout-button {
                position: absolute; /* Positioning the button */
                top: 20px; /* Distance from the top */
                right: 20px; /* Distance from the right */
                background-color: #f44336; /* Red background */
                color: white; /* White text */
                padding: 10px 20px; /* Padding */
                border: none; /* No border */
                border-radius: 5px; /* Rounded corners */
                cursor: pointer; /* Pointer cursor */
                transition: background-color 0.3s, transform 0.3s; /* Smooth transition */
            }
            .logout-button:hover {
                background-color: #d32f2f; /* Darker red on hover */
                transform: translateY(-2px); /* Lift effect on hover */
            }
        </style>
    <title>User Dashboard</title>
</head>
<body>
        <header>
            <h1><img src="pics/one_piesece-removebg-preview.png" alt="One Piece Image" style="max-width: 300px; max-height: 150px; object-fit: contain;"></h1>
            <nav>
                <ul>
                    <li><a href="website/home.html">Home</a></li>
                    <li><a href="https://localhost/New%20folder/login/index.php">Courses</a></li>
                    <li><a href="website/about.html">About</a></li>
                    <li><a href="website/contact.html">Contact Us</a></li>
                </ul>
            </nav>
            <button class="logout-button" onclick="window.location.href='logout.php'">LOG OUT</button>
        </header>
        
        <div class="course-list">
            <h2>Available Courses</h2>
            <div class="course-item">
                <img src="website/images/introtoprogramming-190909184629-thumbnail-4.jpg" alt="Introduction to Programming">
                <div>
                    <h3>Introduction to Programming</h3>
                    <p>Learn the basics of programming with hands-on examples and projects.</p>
                    <button class="enroll-button" onclick="enroll('Introduction to Programming')">Enroll</button>
                </div>
            </div>
            <div class="course-item">
                <img src="website/images/1709920736662.png" alt="Web Development Basics">
                <div>
                    <h3>Web Development Basics</h3>
                    <p>Get started with web development, including HTML, CSS, and JavaScript.</p>
                    <button class="enroll-button" onclick="enroll('Web Development Basics')">Enroll</button>
                </div>
            </div>
            <div class="course-item">
                <img src="website/images/service-14.jpg" alt="Advanced JavaScript">
                <div>
                    <h3>Advanced JavaScript</h3>
                    <p>Deep dive into JavaScript and learn advanced concepts and techniques.</p>
                    <button class="enroll-button" onclick="enroll('Advanced JavaScript')">Enroll</button>
                </div>
            </div>
            <div class="course-item">
                <img src="website/images/FUqHEVVUsAAbZB0-1024x580-1.jpg" alt="Data Science">
                <div>
                    <h3>Data Science</h3>
                    <p>Explore data analysis, visualization, and machine learning techniques.</p>
                    <button class="enroll-button" onclick="enroll('Data Science')">Enroll</button>
                </div>
            </div>
            <div class="course-item">
                <img src="website/images/what-is-machine-learning.jpg" alt="Machine Learning">
                <div>
                    <h3>Machine Learning</h3>
                    <p>Learn the fundamentals of machine learning and its applications.</p>
                    <button class="enroll-button" onclick="enroll('Machine Learning')">Enroll</button>
                </div>
            </div>
            <div class="course-item">
                <img src="website/images/660e8ac66813866c71248853_Choosing-a-Mobile-App-Framework.jpeg" alt="Mobile App Development">
                <div>
                    <h3>Mobile App Development</h3>
                    <p>Build mobile applications for iOS and Android platforms.</p>
                    <button class="enroll-button" onclick="enroll('Mobile App Development')">Enroll</button>
                </div>
            </div>
        </div>
    </body>
</html>
