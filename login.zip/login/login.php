<?php
session_start();
if (isset($_SESSION["user"])) {
   header("Location: index.php");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <style>
        body {
            background-image: url('pics/output-onlinepngtools (1).png'); 
            font-family: Arial, sans-serif;
                margin:auto;
                padding: 0;
                background-size: cover; /* Cover the entire background */
                background-position: center; /* Center the background image */
                overflow-x: hidden; /* Prevent horizontal scroll */
                overflow-y: hidden;
        
        }

        header {
            background: rgba(255, 255, 255, 0.8); /* Semi-transparent background for header */
            padding: 1.5em;
            text-align: center;
            border-bottom: 2px solid #fff;
            animation: fadeIn 1s; /* Fade-in animation */
            display: flex;
            justify-content: center; /* Center image horizontally */
            align-items: center; /* Center image vertically */
        }

        @keyframes fadeIn {
            from { opacity: 0; }
            to { opacity: 1; }
        }

        h1 {
            color: violet;
            text-align: center;
            animation: slideIn 1s; /* Slide-in animation */
        }

        @keyframes slideIn {
            from { transform: translateY(-20px); opacity: 0; }
            to { transform: translateY(0); opacity: 1; }
        }

        hr {
            color: aqua;
            border: 2px;
        }

        .container {
            width: 400px;
            margin: 50px auto;
            padding: 20px;
            background-color: rgba(255, 255, 255, 0.8); /* Slightly more transparent for better visibility */
            border-radius: 8px;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2);
            text-align: left;
        }

        .form-group {
            margin: 10px 0;
        }

        .form-group input {
            width: 380px;
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 5px;
            transition: border-color 0.3s, transform 0.3s;
        }

        .form-group input:focus {
            border-color: #4CAF50;
            transform: scale(1.02);
        }

        .form-btn input {
            background-color: #4CAF50;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 5px;
            cursor: pointer;
            transition: background-color 0.3s;
            width: 100%;
        }

        .form-btn input:hover {
            background-color: #45a049;
        }

        .signup-link {
            text-align: center;
            margin-top: 15px;
            transition: transform 0.3s;
        }

        .signup-link:hover {
            transform: scale(1.1);
            color: #4CAF50;
        }

        .alert {
            margin-top: 10px;
            padding: 10px;
            border-radius: 5px;
        }

        .alert-danger {
            background-color: #f8d7da;
            color: #721c24;
        }

        .alert-success {
            background-color: #d4edda;
            color: #155724;
        }
        nav {
            margin: 20px 0;
        }
        nav ul {
            list-style: none;
            margin: 0;
            padding: 0;
            display: flex;
            justify-content: center; /* Center the navigation */
        }
        nav li {
            margin: 0 15px; /* Space between boxes */
        }
        nav a {
            display: block; /* Make the link a block element */
            background-color: rgba(255, 255, 255, 0.8); /* Light background for boxes */
            padding: 12px 25px; /* Padding for the boxes */
            border-radius: 8px; /* Rounded corners */
            text-decoration: none;
            color: #333;
            transition: background-color 0.3s, transform 0.3s; /* Smooth transition */
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.2); /* Shadow for depth */
        }
        nav a:hover {
            background-color: #ddd; /* Darker background on hover */
            transform: translateY(-2px); /* Lift effect on hover */
        }
    </style>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Form</title>

</head>
<body>
    <header>
        <center>
        <!-- Set header image -->
        <img src="pics/one_piesece-removebg-preview.png" alt="One Piece Image" style="max-width: 300px; max-height: 150px; object-fit: contain;">
        </center>
    </header>

    <div class="container">
        <?php
        if (isset($_POST["login"])) {
           $email = $_POST["email"];
           $password = $_POST["password"];
            require_once "database.php";
            $sql = "SELECT * FROM users WHERE email = '$email'";
            $result = mysqli_query($conn, $sql);
            $user = mysqli_fetch_array($result, MYSQLI_ASSOC);
            if ($user) {
                if (password_verify($password, $user["password"])) {
                    session_start();
                    $_SESSION["user"] = "yes";
                    header("Location: index.php");
                    die();
                } else {
                    echo "<div class='alert alert-danger'>Password does not match</div>";
                }
            } else {
                echo "<div class='alert alert-danger'>Email does not match</div>";
            }
        }
        ?>
        <br>
        <h1>Login Page</h1>
      <form action="login.php" method="post">
        <div class="form-group">
            <input type="email" placeholder="Enter Email:" name="email" class="form-control" required>
        </div>
        <div class="form-group">
            <input type="password" placeholder="Enter Password:" name="password" class="form-control" required>
        </div>
        <div class="form-btn">
            <input type="submit" value="Login" name="login" class="btn btn-primary">
        </div>
      </form>
     <div><p>Not registered yet? <a href="registration.php">Register Here</a></p></div>
    </div>
</body>
</html>
